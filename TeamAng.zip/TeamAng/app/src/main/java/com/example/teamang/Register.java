package com.example.teamang;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;

public class Register extends AppCompatActivity {

    EditText etEmail, etUser, etFname, etMname, etLname, etAddress, etPass, etCpass, etContact;
    ImageView imgProfile;
    Button btnBack, btnChoosePhoto, btnRegister;
    ProgressDialog progressDialog;
    Uri imageUri;
    String encoded_string;
    private static final int CODE_POST_REQUEST = 1025;
    private static final int CHOOSE_IMAGE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUser = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        etFname = findViewById(R.id.etFname);
        etMname = findViewById(R.id.etMname);
        etLname = findViewById(R.id.etLname);
        etPass = findViewById(R.id.etPassword);
        etCpass = findViewById(R.id.etCpassword);
        etContact = findViewById(R.id.etContact);
        etAddress = findViewById(R.id.etAddress);
        imgProfile = findViewById(R.id.etProfile);
        btnBack = findViewById(R.id.btnBack);
        btnChoosePhoto = findViewById(R.id.btnPhoto);
        btnRegister = findViewById(R.id.btnRegister);
        progressDialog = new ProgressDialog(this);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Back();
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
        btnChoosePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choosePhoto();
                Toast.makeText(getApplicationContext(),encoded_string,Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void registerUser() {

        String  email, username, fname, mname, lname, address, pass, cpass, contact;

        email = etEmail.getText().toString();
        username = etUser.getText().toString();
        fname = etFname.getText().toString();
        mname = etMname.getText().toString();
        lname = etLname.getText().toString();
        address = etAddress.getText().toString();
        pass = etPass.getText().toString();
        cpass = etCpass.getText().toString();
        contact = etContact.getText().toString();

        if(email.isEmpty()){
            etEmail.setError("Enter your Email Address");
            etEmail.requestFocus();
        }

        if(username.isEmpty()){
            etUser.setError("Enter your Email Address");
            etUser.requestFocus();
        }

        if(fname.isEmpty()){
            etFname.setError("Enter your Firstname");
            etFname.requestFocus();
        }

        if(lname.isEmpty()){
            etLname.setError("Enter your Lastname");
            etLname.requestFocus();
        }

        if(address.isEmpty()){
            etAddress.setError("Enter you Address");
            etAddress.requestFocus();
        }

        if(contact.isEmpty()){
            etContact.setError("Enter your Contact");
            etContact.requestFocus();
        }

        if(!pass.equals(cpass)){
            etPass.setError("Password and Confirm Password doesn't match");
            etPass.requestFocus();
        }

        if(pass.isEmpty()){
            etPass.setError("Enter your Password");
            etPass.requestFocus();
        }else if(cpass.isEmpty()){
            etCpass.setError("Enter your Confirm Password");
            etCpass.requestFocus();
        }

        if(pass.length() < 8 && pass.length() !=0){
            etPass.setError("Please enter password more than 8 characters");
            etPass.setError("Please enter password more than 8 characters");
        }

        if(encoded_string == null){
            Toast.makeText(getApplicationContext(),"Please Select a Photo", Toast.LENGTH_SHORT).show();
        }


        Toast.makeText(this, fname + " " + lname + " " + mname + " " + username + " " + address + " " + pass + " " + contact + " " + email + " " + encoded_string , Toast.LENGTH_SHORT).show();

        if(!email.isEmpty() && !username.isEmpty() && !fname.isEmpty() && !lname.isEmpty() && !address.isEmpty()
                && !contact.isEmpty() && pass.equals(cpass) && !encoded_string.isEmpty()){

            HashMap<String, String> params = new HashMap<>();
            params.put("fname", fname);
            params.put("mname", mname);
            params.put("lname", lname);
            params.put("username", username);
            params.put("address", address);
            params.put("password", pass);
            params.put("contact", contact);
            params.put("email",email);
            params.put("image", encoded_string);

            Register.PerformNetworkRequest request = new Register.PerformNetworkRequest(Links.REGISTER, params, CODE_POST_REQUEST);
            request.execute();
        }
    }

    private void Back() {
        startActivity(new Intent(this, Login.class));
    }

    class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

        //the url where we need to send the request
        String url;

        //the parameters
        HashMap<String, String> params;

        //the request code to define whether it is a GET or POST
        int requestCode;

        //constructor to initialize values
        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        //when the task started displaying a progressbar
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Registering Account Please wait...");
            progressDialog.show();
        }


        //this method will give the response from the request
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            Log.e("LOOK", s);
            try {
                JSONObject object2 = new JSONObject(s);
                if (!object2.getBoolean("error2")) {
                    Toast.makeText(getApplicationContext(), object2.getString("message2"), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),Login.class));
                    finish();
                }else{
                    Toast.makeText(getApplicationContext(), object2.getString("message2"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //the network operation will be performed in background
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);
            return null;
        }
    }

    private void choosePhoto() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Profile Picture"), CHOOSE_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CHOOSE_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null){
            imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),imageUri);
                int nh = (int) ( bitmap.getHeight() * (720.0 / bitmap.getWidth()) );
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 720, nh, true);
                encoded_string = encodeTobase64(scaled);
                imgProfile.setImageBitmap(scaled);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    public static String encodeTobase64(Bitmap image) {
        Bitmap immagex = image;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        immagex.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b,Base64.DEFAULT);
        Log.e("LOOK", imageEncoded);
        return imageEncoded;
    }


}
