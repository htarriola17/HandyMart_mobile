package com.example.teamang;

public class Links {
    public static final int CODE_POST_REQUEST = 1025;
    public static  final String BASE_URL = "http://mbb-oirs.com/";
    public static  final String LOGIN = BASE_URL+"hackathon/LoginUser";
    public static  final String REGISTER = BASE_URL+"hackathon/RegisterUser";
}
