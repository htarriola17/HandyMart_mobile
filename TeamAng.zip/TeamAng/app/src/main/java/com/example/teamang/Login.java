package com.example.teamang;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Login extends AppCompatActivity {

    private static final int CODE_POST_REQUEST = 1025;
    int logStatus;
    EditText etEmail, etPassword;
    Button btnLogin, btnRegister;
    ProgressDialog progressDialog;
    String fname,lname,mname,contact,ewallet,address,email,username,imgProfile;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sp = getSharedPreferences("x", MODE_PRIVATE);
        if(sp.contains("logstatus")) {
            logStatus = sp.getInt("logstatus",0);
        }
        if(logStatus == 1){
            startActivity(new Intent(this,Dashboard.class));
            finish();
        }

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        progressDialog = new ProgressDialog(this);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });
    }

    public void loginUser(){

        String email, password;

        email = etEmail.getText().toString();
        password = etPassword.getText().toString();

        if(email.isEmpty()){
            etEmail.setError("Please enter your email!");
            etEmail.requestFocus();
        }
        if(password.isEmpty()){
            etPassword.setError("Please enter your password!");
            etPassword.requestFocus();
        }

        if(!password.isEmpty() && !email.isEmpty()){

                HashMap<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);

                Login.PerformNetworkRequest request = new Login.PerformNetworkRequest(Links.LOGIN, params, CODE_POST_REQUEST);
                request.execute();

                progressDialog.setMessage("Logging in Please wait...");
                progressDialog.show();
                progressDialog.setCancelable(false);
            }
        }

    public void registerUser(){
        startActivity(new Intent(this,Register.class));
        finish();
    }

    class PerformNetworkRequest extends AsyncTask<Void, Void, String> {

        //the url where we need to send the request
        String url;

        //the parameters
        HashMap<String, String> params;

        //the request code to define whether it is a GET or POST
        int requestCode;

        //constructor to initialize values
        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        //when the task started displaying a progressbar
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Logging in Account Please wait...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject object2 = new JSONObject(s);
                if (!object2.getBoolean("error2")) {
                    getJSONObject(object2.getJSONArray("user"));
                    Toast.makeText(getApplicationContext(),object2.getString("message2"),Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Dashboard.class));
                    finish();
                }else{
                    Toast.makeText(getApplicationContext(),object2.getString("message2"),Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();

            }
        }

        //the network operation will be performed in background
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == Links.CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);
            return null;
        }
    }

    private void getJSONObject(JSONArray user) throws JSONException {
        for (int i = 0; i < user.length(); i++) {
            JSONObject obj = user.getJSONObject(i);
            fname = obj.getString("fname").toString();
            mname = obj.getString("mname").toString();
            lname = obj.getString("lname").toString();
            contact = obj.getString("contactno").toString();
            username = obj.getString("username").toString();
            address = obj.getString("address").toString();
            email  = obj.getString("email").toString();
            ewallet = obj.getString("ewallet").toString();
            imgProfile = obj.getString("imgprofile").toString();
        }

        logStatus = 1;
        SharedPreferences sp = getApplication().getSharedPreferences("x", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt("logstatus", logStatus);
        editor.putString("fname",fname);
        editor.putString("lname",lname);
        editor.putString("mname",mname);
        editor.putString("contact",contact);
        editor.putString("address",address);
        editor.putString("username",username);
        editor.putString("ewallet",ewallet);
        editor.putString("email", email);
        editor.putString("imgProfile", imgProfile);
        editor.commit();

    }
}
