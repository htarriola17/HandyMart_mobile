package com.example.teamang;

public class Items {
    String name, description;
}
