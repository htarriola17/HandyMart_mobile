package com.example.teamang;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class UserProfile extends Fragment {

    ImageView imgProfile;
    String fname, lname, mname, email, image, username;
    int logStatus, ewallet;

    TextView txtName, txtUsername, txtCredits;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        SharedPreferences sp = getActivity().getSharedPreferences("x", getActivity().MODE_PRIVATE);
        if(sp.contains("logstatus")) {
            logStatus = sp.getInt("logstatus", 0);
            fname = sp.getString("fname", null);
            lname = sp.getString("lname", null);
            email = sp.getString("email", null);
            image = sp.getString("imgProfile",null);
            mname = sp.getString("mname", null);
            ewallet = Integer.parseInt(sp.getString("ewallet", null));
            username = sp.getString("username",null);
        }

        return inflater.inflate(R.layout.fragment_user_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        txtName = view.findViewById(R.id.txtName);
        txtUsername = view.findViewById(R.id.txtUsername);
        txtCredits  = view.findViewById(R.id.etCredits);
        imgProfile = view.findViewById(R.id.imageView2);

        txtName.setText(fname+ " " + mname + " " + lname);
        txtUsername.setText(username);
        txtCredits.setText(String.valueOf(ewallet));
        String imgUrl = Links.BASE_URL + "/assets/img/participants/" + image;
        if(image != null){
            Picasso.get().load(imgUrl).placeholder(R.mipmap.ic_launcher).into(imgProfile);
        }

    }
}
