package com.example.teamang;


import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class Shop extends Fragment {

    Button btnPlay1, btnPlay2, btnPlay3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_shop, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnPlay1 = view.findViewById(R.id.btnPlayDemo1);
        btnPlay2 = view.findViewById(R.id.btnPlayDemo2);
        btnPlay3 = view.findViewById(R.id.btnPlayDemo);

        btnPlay1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openScanner();
            }
        });

        btnPlay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openScanner();
            }
        });

        btnPlay3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openScanner();
            }
        });
    }

    public void openScanner(){
        Context ctx = getActivity(); // or you can replace **'this'** with your **ActivityName.this**
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage("com.sam.lgapp");
        ctx.startActivity(i);
    }
}
